#include <msp430.h>

/*
 * main.c
 */

        void main(void) {
            WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer

            volatile float Xvoltage;                                //Values used for X axis on the Analog
            volatile float XLow, XHigh, XMed;                       //Values used for X axis on the Analog

            volatile float Yvoltage;                                //Values used for Y Axis on the Analog
            volatile float YLow, YHigh, YMed;                       //Values used for Y Axis on the Analog


            XLow = 0.00;
                YLow = 0.00;

            XMed = 1.75;
                YMed = 1.75;

            XHigh = 2.5;
                YHigh = 2.5;


                ADC10CTL0 = SREF_0 | ADC10SHT_2 | ADC10ON;
                ADC10CTL1 = INCH_1 | SHS_0 | ADC10DIV_0 | ADC10SSEL_0 | CONSEQ_0;
                ADC10AE0 = BIT1 | BIT0;
                ADC10CTL0 |= ENC;

                P2DIR = 0x07;                                       //Used for the Output to the LED's on the Breadboard

           while (1) {
               ADC10CTL1 = INCH_1 | SHS_0 | ADC10DIV_0 | ADC10SSEL_0 | CONSEQ_0;
               ADC10CTL0 |= ADC10SC;
               while (ADC10CTL1 & BUSY);

               Xvoltage = ((ADC10MEM * 3.55)/0x03FF);

               Yvoltage = ((ADC10MEM * 3.55)/0x3FF);
               __delay_cycles(1000);


         //Step 1 LED Initiation

                   if (Yvoltage <= YMed/2){
                        P2OUT = BIT0;}
                   else if (Yvoltage >= YHigh){
                        P2OUT = BIT2;}
                    else if(Yvoltage >= YLow/2){
                        P2OUT = BIT1;}
                }


                if (Xvoltage <= XMed/2){
                     P2OUT = BIT0;}
                else if (Xvoltage >= XHigh){
                     P2OUT = BIT2 ;}
                else if(Xvoltage >= XLow/2){
                    P2OUT = BIT1;}
           }



          // Step 2 Binary Values
/*
               if (Xvoltage <= XMed/2){
                             P2OUT = BIT2;}
                        else if (Xvoltage >= XHigh){
                             P2OUT = BIT1 | BIT2;}
                        else if(Xvoltage >= XLow/2){
                            P2OUT = BIT1;}
               }
/*

               if (Yvoltage <= YMed/2){
                              P2OUT = BIT0;}
                         else if (Xvoltage >= XHigh){
                              P2OUT = BIT0 | BIT1;}
                         else if(Xvoltage >= XLow/2){
                              P2OUT = BIT0 | BIT2 ;}
                         }

        }

*/

